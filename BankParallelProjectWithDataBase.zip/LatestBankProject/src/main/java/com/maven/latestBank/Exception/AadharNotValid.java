package com.maven.latestBank.Exception;

public class AadharNotValid extends Exception{
	public AadharNotValid(String s) {
		System.out.println(s);
	}
}
