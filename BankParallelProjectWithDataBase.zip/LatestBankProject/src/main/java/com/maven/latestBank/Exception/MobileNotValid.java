package com.maven.latestBank.Exception;

public class MobileNotValid extends Exception{
	public MobileNotValid(String s) {
		System.out.println(s);
	}
}
