package com.maven.latestBank.Exception;

public class EmailNotValid extends Exception{
	public EmailNotValid(String s) {
		System.out.println("Email is not valid");
	}
}
