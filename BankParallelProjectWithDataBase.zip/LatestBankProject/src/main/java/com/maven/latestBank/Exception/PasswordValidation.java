package com.maven.latestBank.Exception;

public class PasswordValidation extends Exception{
	public PasswordValidation(String s) {
		System.out.println(s);
	}
}
